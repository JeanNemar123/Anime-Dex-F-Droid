# Services tiers utilisés par AnimeDex

À vérifier avant publication et à décrire dans la fiche F-Droid :

- AniList : données de catalogue via GraphQL.
- Jikan / MyAnimeList : données de catalogue via l'API Jikan.
- Kitsu : données de catalogue.
- MyMemory : traduction de descriptions/texte si activée.
- YouTube no-cookie : lecture/intégration de bandes-annonces.
- Serveur AnimeDex sur Vercel : création de comptes, connexion et synchronisation.

Les conditions d'utilisation, la politique de confidentialité, les éventuelles
limites de débit et la qualification F-Droid des services externes doivent être
examinées séparément. Le code fourni ne permet pas de conclure que tous ces
services sont libres ou disponibles sans restriction.
