# Préparation F-Droid — AnimeDex

Identifiant Android : `com.animedex.app`  
Version Android préparée : `1.0.0` (`versionCode` 1)  
Licence déclarée : `GPL-3.0-only` (`LICENSE`).

## Changements de cette préparation

- Remplacement du projet Capacitor généré dynamiquement par une application Android native minimale basée sur le WebView système.
- Ajout du projet Gradle `android/` dans les sources.
- Intégration des fichiers web locaux depuis `public/` dans `android/app/src/main/assets/public/`.
- Chargement des assets via un hôte HTTPS local intercepté par le WebView, afin d'éviter l'origine opaque `null` de `file://`.
- Ajout d'une tâche Gradle `syncWebAssets` qui recopie les sources web locales avant `preBuild`.
- Suppression des dépendances npm Capacitor : l'application web n'utilise pas de paquet npm à l'exécution.
- Ajout d'un `package-lock.json` minimal cohérent avec le `package.json` sans dépendances npm.
- Mise à jour du workflow GitHub Actions pour produire un APK release non signé.

## Services distants conservés

Le code conserve le serveur de comptes/synchronisation configuré dans `public/app.js` :
`https://animedex-mk6owt0bu-iyadelyakchoues-projects.vercel.app`.

Le catalogue interroge également des services externes (AniList, Jikan, Kitsu, MyMemory et les intégrations YouTube). L'application n'est donc pas entièrement utilisable hors ligne. La fiche F-Droid devra décrire clairement ces dépendances réseau et déclarer les Anti-Features que les mainteneurs jugeront applicables, notamment `NonFreeNet` si l'usage de services réseau non libres est confirmé.

## Ce qui n'est pas encore validé

Cette archive est une préparation de sources, pas une soumission F-Droid certifiée.

1. La compilation Android n'a pas pu être exécutée ici : l'environnement de travail ne dispose pas d'un SDK Android/Gradle configuré et l'accès npm a expiré pendant la tentative de génération du lockfile initial.
2. Le workflow GitHub utilise `--offline` : il doit être exécuté pour confirmer que le runner dispose bien des dépendances Gradle préchargées. Si ce n'est pas le cas, enlever `--offline` pour le workflow de développement uniquement ; la recette F-Droid doit, elle, être testée dans son environnement isolé.
3. Le comportement des requêtes cross-origin depuis l'origine locale `https://appassets.androidplatform.net` doit être testé sur un appareil Android réel. Le projet intercepte cet hôte dans le WebView et sert les fichiers depuis les assets Android, sans bibliothèque tierce.
4. Vérifier les licences de toutes les ressources, bibliothèques et services externes, les permissions et le comportement de confidentialité.
5. Créer un tag de version stable, puis utiliser le hash complet du commit dans le fichier de métadonnées F-Droid.
6. Exécuter `fdroid lint` et `fdroid build` dans un environnement fdroidserver avant toute demande d'intégration.

## Modèle de métadonnées

Un exemple non final est fourni dans `fdroid/metadata/com.animedex.app.yml.example`. Il contient volontairement un marqueur de commit à remplacer : ne pas le soumettre tel quel.
