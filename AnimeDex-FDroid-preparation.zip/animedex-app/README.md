# AnimeDex

Catalogue d’animés (AniList, MyAnimeList via Jikan et Kitsu, fusionnés sans doublons) avec favoris, vus, « à regarder », progression des épisodes, statistiques, bandes-annonces, **comptes (pseudo + mot de passe)** et **synchronisation entre appareils**. Installable sur téléphone (PWA).

## Lancer en local
Node 22.13 ou plus récent, aucune dépendance à installer :

    node server.js

Puis ouvre http://localhost:3000. Les comptes sont stockés dans `data/animedex.db` (SQLite).

## Mettre en ligne
Le serveur a besoin d’un **stockage persistant** pour `DB_PATH` (par défaut `/data/animedex.db` dans Docker) et d’**HTTPS** (fourni par la plupart des hébergeurs). Options : Fly.io (volume), Railway (volume), Render (disque payant), ou un VPS avec Docker.

    docker build -t animedex .
    docker run -p 3000:3000 -v animedex-data:/data animedex

Variables : `PORT` (3000), `DB_PATH`, `TRUST_PROXY=1` si le serveur est derrière un proxy (pour limiter les tentatives de connexion par IP réelle).

## GitHub
Le workflow `.github/workflows/docker.yml` vérifie le code puis publie l’image Docker sur `ghcr.io/<ton-compte>/<repo>:latest` à chaque push sur `main`. Ton hébergeur peut ensuite la déployer.

## Application Android
Le dossier `android/` contient une application Android native minimale qui affiche les fichiers locaux de `public/` dans un WebView système. Aucun projet Android n'est généré pendant la compilation et aucune dépendance Capacitor/npm n'est nécessaire pour construire l'APK.

Pour synchroniser les fichiers web dans les assets Android :

    ./scripts/sync-android-assets.sh

Pour compiler localement (JDK 17, Android SDK API 36 et Gradle 8.13 ou compatible) :

    cd android
    gradle assembleRelease

L'APK de sortie est `android/app/build/outputs/apk/release/app-release-unsigned.apk`. Il est non signé et destiné à la vérification/au processus de signature F-Droid, pas à une distribution personnelle immédiate.

Le workflow GitHub Actions **Android release build** effectue la synchronisation des assets et produit un APK release non signé. La compilation F-Droid devra être testée séparément dans l'environnement `fdroidserver`.

L'adresse du serveur de comptes est écrite dans `public/app.js` (constante `SERVER`). Il reste un service distant HTTPS : les fonctions de compte et de synchronisation nécessitent une connexion réseau et dépendent de sa disponibilité.

## Installer sur téléphone (sans APK)
Ouvre le site en HTTPS dans Chrome (Android) ou Safari (iOS) puis « Ajouter à l’écran d’accueil ».

## Sécurité et limites
- Mots de passe hachés avec scrypt et sel ; sessions de 90 jours ; 20 tentatives de connexion par 10 minutes et par IP.
- Aucune récupération de mot de passe (pas d’e-mail). Sauvegarde le fichier de base de données.
- Synchronisation : le serveur garde la dernière version ; en cas de modifications simultanées sur deux appareils, les listes sont fusionnées (une suppression faite en même temps peut réapparaître).
- Les données d’animés viennent d’AniList : respecte leurs conditions d’utilisation si tu rends le site public.
